// Weather app configuration and data
const API_CONFIG = {
    forecast: 'https://api.open-meteo.com/v1/forecast',
    geocoding: 'https://geocoding-api.open-meteo.com/v1/search'
};

// Weather code mapping to emojis and descriptions
const WEATHER_CODES = {
    0: { condition: 'Clear sky', icon: '☀️', description: 'Clear and sunny weather' },
    1: { condition: 'Mainly clear', icon: '🌤️', description: 'Mostly clear skies' },
    2: { condition: 'Partly cloudy', icon: '⛅', description: 'Partly cloudy conditions' },
    3: { condition: 'Overcast', icon: '☁️', description: 'Overcast skies' },
    45: { condition: 'Fog', icon: '🌫️', description: 'Foggy conditions' },
    48: { condition: 'Depositing rime fog', icon: '🌫️', description: 'Dense fog' },
    51: { condition: 'Light drizzle', icon: '🌦️', description: 'Light drizzle' },
    53: { condition: 'Moderate drizzle', icon: '🌦️', description: 'Moderate drizzle' },
    55: { condition: 'Dense drizzle', icon: '🌧️', description: 'Heavy drizzle' },
    61: { condition: 'Slight rain', icon: '🌧️', description: 'Light rain' },
    63: { condition: 'Moderate rain', icon: '🌧️', description: 'Moderate rain' },
    65: { condition: 'Heavy rain', icon: '🌧️', description: 'Heavy rainfall' },
    71: { condition: 'Slight snow', icon: '🌨️', description: 'Light snowfall' },
    73: { condition: 'Moderate snow', icon: '❄️', description: 'Moderate snowfall' },
    75: { condition: 'Heavy snow', icon: '❄️', description: 'Heavy snowfall' },
    80: { condition: 'Slight rain showers', icon: '🌦️', description: 'Light rain showers' },
    81: { condition: 'Moderate rain showers', icon: '🌧️', description: 'Moderate rain showers' },
    82: { condition: 'Violent rain showers', icon: '⛈️', description: 'Heavy rain showers' },
    95: { condition: 'Thunderstorm', icon: '⛈️', description: 'Thunderstorm' },
    96: { condition: 'Thunderstorm with hail', icon: '⛈️', description: 'Thunderstorm with light hail' },
    99: { condition: 'Thunderstorm with heavy hail', icon: '⛈️', description: 'Severe thunderstorm with hail' }
};

// Default locations fallback
const DEFAULT_LOCATIONS = [
    { name: 'New York', lat: 40.7128, lon: -74.0060, country: 'US' },
    { name: 'London', lat: 51.5074, lon: -0.1278, country: 'GB' },
    { name: 'Tokyo', lat: 35.6762, lon: 139.6503, country: 'JP' },
    { name: 'Mumbai', lat: 19.0760, lon: 72.8777, country: 'IN' },
    { name: 'Delhi', lat: 28.6139, lon: 77.2090, country: 'IN' }
];

// Global state
let currentLocation = null;
let isCelsius = true;
let searchTimeout = null;
let lastUpdateTime = null;
let autoRefreshInterval = null;
let currentWeatherData = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    setupEventListeners();
    loadPreferences();
    tryGetCurrentLocation();
    setupAutoRefresh();
}

function setupEventListeners() {
    // Search functionality
    const citySearch = document.getElementById('citySearch');
    const searchBtn = document.getElementById('searchBtn');
    const locationBtn = document.getElementById('locationBtn');
    const searchSuggestions = document.getElementById('searchSuggestions');

    citySearch.addEventListener('input', handleSearchInput);
    citySearch.addEventListener('keypress', handleSearchKeypress);
    citySearch.addEventListener('focus', handleSearchFocus);
    citySearch.addEventListener('blur', handleSearchBlur);
    
    searchBtn.addEventListener('click', handleSearch);
    locationBtn.addEventListener('click', handleLocationRequest);
    
    searchSuggestions.addEventListener('click', handleSuggestionClick);

    // Temperature toggle
    const tempToggle = document.getElementById('tempToggle');
    tempToggle.addEventListener('click', toggleTemperatureUnit);

    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    refreshBtn.addEventListener('click', handleRefresh);

    // Error modal
    const closeError = document.getElementById('closeError');
    const retryBtn = document.getElementById('retryBtn');
    closeError.addEventListener('click', hideErrorModal);
    retryBtn.addEventListener('click', handleRetry);

    // Window events
    window.addEventListener('focus', handleWindowFocus);
}

// Search functionality
function handleSearchInput(e) {
    const query = e.target.value.trim();
    
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }

    if (query.length < 2) {
        hideSuggestions();
        return;
    }

    // Show loading indicator in suggestions
    const container = document.getElementById('searchSuggestions');
    container.innerHTML = '<div class="suggestion-item">🔍 Searching...</div>';
    container.classList.remove('hidden');

    searchTimeout = setTimeout(() => {
        searchCities(query);
    }, 300);
}

function handleSearchKeypress(e) {
    if (e.key === 'Enter') {
        const query = e.target.value.trim();
        if (query) {
            performDirectSearch(query);
        }
    }
}

function handleSearchFocus(e) {
    const query = e.target.value.trim();
    if (query.length >= 2) {
        searchCities(query);
    }
}

function handleSearchBlur() {
    setTimeout(() => {
        hideSuggestions();
    }, 200);
}

function handleSearch() {
    const query = document.getElementById('citySearch').value.trim();
    if (query) {
        performDirectSearch(query);
    }
}

async function searchCities(query) {
    try {
        const response = await fetch(`${API_CONFIG.geocoding}?name=${encodeURIComponent(query)}&count=8&language=en&format=json`);
        
        if (!response.ok) {
            throw new Error('Search failed');
        }

        const data = await response.json();
        
        if (data.results && data.results.length > 0) {
            showSuggestions(data.results);
        } else {
            showNoResults();
        }
    } catch (error) {
        console.error('Search error:', error);
        showSearchError();
    }
}

function showSuggestions(cities) {
    const container = document.getElementById('searchSuggestions');
    
    container.innerHTML = cities.map(city => {
        const displayName = `${city.name}`;
        const country = city.country || '';
        const admin1 = city.admin1 ? `, ${city.admin1}` : '';
        
        return `
            <div class="suggestion-item" data-lat="${city.latitude}" data-lon="${city.longitude}" data-name="${city.name}" data-country="${country}">
                <span>${displayName}${admin1}</span>
                <span class="suggestion-country">${country}</span>
            </div>
        `;
    }).join('');
    
    container.classList.remove('hidden');
}

function showNoResults() {
    const container = document.getElementById('searchSuggestions');
    container.innerHTML = '<div class="suggestion-item">❌ No cities found</div>';
    container.classList.remove('hidden');
}

function showSearchError() {
    const container = document.getElementById('searchSuggestions');
    container.innerHTML = '<div class="suggestion-item">⚠️ Search failed. Please try again.</div>';
    container.classList.remove('hidden');
}

function hideSuggestions() {
    document.getElementById('searchSuggestions').classList.add('hidden');
}

function handleSuggestionClick(e) {
    const item = e.target.closest('.suggestion-item');
    if (item && item.dataset.lat) {
        const lat = parseFloat(item.dataset.lat);
        const lon = parseFloat(item.dataset.lon);
        const name = item.dataset.name;
        const country = item.dataset.country;
        
        selectLocation({ lat, lon, name, country });
        document.getElementById('citySearch').value = '';
        hideSuggestions();
    }
}

async function performDirectSearch(query) {
    try {
        showLoading();
        const response = await fetch(`${API_CONFIG.geocoding}?name=${encodeURIComponent(query)}&count=1&language=en&format=json`);
        
        if (!response.ok) {
            throw new Error('Search failed');
        }

        const data = await response.json();
        
        if (data.results && data.results.length > 0) {
            const city = data.results[0];
            await selectLocation({
                lat: city.latitude,
                lon: city.longitude,
                name: city.name,
                country: city.country || ''
            });
        } else {
            hideLoading();
            showErrorModal('City not found. Please try a different search term.');
        }
        
        document.getElementById('citySearch').value = '';
        hideSuggestions();
    } catch (error) {
        hideLoading();
        showErrorModal('Search failed. Please check your connection and try again.');
    }
}

// Location functionality
function handleLocationRequest() {
    if (navigator.geolocation) {
        const btn = document.getElementById('locationBtn');
        btn.innerHTML = '<span>⏳</span>';
        btn.disabled = true;
        
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const { latitude, longitude } = position.coords;
                await selectLocation({ lat: latitude, lon: longitude, name: 'Your Location', country: '' });
                btn.innerHTML = '<span>📍</span>';
                btn.disabled = false;
            },
            (error) => {
                console.error('Geolocation error:', error);
                showErrorModal('Unable to access your location. Please search for a city manually.');
                btn.innerHTML = '<span>📍</span>';
                btn.disabled = false;
            },
            { timeout: 10000, enableHighAccuracy: true }
        );
    } else {
        showErrorModal('Geolocation is not supported by your browser.');
    }
}

function tryGetCurrentLocation() {
    // Try to load last saved location first
    const savedLocation = loadPreferences().lastLocation;
    if (savedLocation) {
        selectLocation(savedLocation);
        return;
    }

    // Try geolocation silently
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const { latitude, longitude } = position.coords;
                await selectLocation({ lat: latitude, lon: longitude, name: 'Your Location', country: '' });
            },
            () => {
                // Fallback to default location
                selectLocation(DEFAULT_LOCATIONS[0]);
            },
            { timeout: 5000, enableHighAccuracy: false }
        );
    } else {
        // Fallback to default location
        selectLocation(DEFAULT_LOCATIONS[0]);
    }
}

async function selectLocation(location) {
    currentLocation = location;
    savePreferences();
    await fetchWeatherData(location.lat, location.lon, location.name);
}

// Weather data fetching
async function fetchWeatherData(lat, lon, locationName) {
    try {
        showLoading();
        
        const params = new URLSearchParams({
            latitude: lat,
            longitude: lon,
            current: 'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,pressure_msl,visibility',
            hourly: 'temperature_2m,weather_code,relative_humidity_2m',
            daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,uv_index_max',
            timezone: 'auto'
        });

        const response = await fetch(`${API_CONFIG.forecast}?${params}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        currentWeatherData = data; // Store for detailed views
        
        updateWeatherDisplay(data, locationName);
        updateLastUpdated();
        hideLoading();
        
    } catch (error) {
        console.error('Weather fetch error:', error);
        hideLoading();
        showErrorModal('Failed to fetch weather data. Please check your connection and try again.');
    }
}

function updateWeatherDisplay(data, locationName) {
    updateCurrentWeather(data.current, locationName);
    updateHourlyForecast(data.hourly);
    updateDailyForecast(data.daily);
}

function updateCurrentWeather(current, locationName) {
    const weatherInfo = WEATHER_CODES[current.weather_code] || WEATHER_CODES[0];
    
    // Update main weather display
    document.getElementById('currentTemp').textContent = formatTemperature(current.temperature_2m);
    document.getElementById('currentCity').textContent = locationName;
    document.getElementById('currentDescription').textContent = weatherInfo.description;
    document.getElementById('currentIcon').textContent = weatherInfo.icon;
    document.getElementById('currentDateTime').textContent = formatDateTime();
    
    // Update weather details
    document.getElementById('humidity').textContent = `${Math.round(current.relative_humidity_2m)}%`;
    document.getElementById('windSpeed').textContent = `${Math.round(current.wind_speed_10m)} km/h`;
    document.getElementById('feelsLike').textContent = formatTemperature(current.apparent_temperature);
    document.getElementById('pressure').textContent = `${Math.round(current.pressure_msl)} hPa`;
    document.getElementById('visibility').textContent = `${Math.round(current.visibility / 1000)} km`;
    document.getElementById('uvIndex').textContent = '--'; // Will be updated from daily
}

function updateHourlyForecast(hourly) {
    const container = document.getElementById('hourlyCards');
    container.innerHTML = '';
    
    // Show next 24 hours
    for (let i = 1; i <= 24; i++) {
        if (i < hourly.time.length) {
            const time = new Date(hourly.time[i]);
            const weatherInfo = WEATHER_CODES[hourly.weather_code[i]] || WEATHER_CODES[0];
            
            const card = document.createElement('div');
            card.className = 'hourly-card fade-in';
            card.style.animationDelay = `${i * 0.05}s`;
            
            card.innerHTML = `
                <div class="hourly-time">${formatHour(time)}</div>
                <div class="hourly-icon">${weatherInfo.icon}</div>
                <div class="hourly-temp">${formatTemperature(hourly.temperature_2m[i])}</div>
                <div class="hourly-condition">${weatherInfo.condition}</div>
            `;
            
            container.appendChild(card);
        }
    }
}

function updateDailyForecast(daily) {
    const container = document.getElementById('forecastCards');
    container.innerHTML = '';
    
    // Update UV index from daily data
    if (daily.uv_index_max && daily.uv_index_max[0]) {
        document.getElementById('uvIndex').textContent = Math.round(daily.uv_index_max[0]);
    }
    
    // Show 7-day forecast
    for (let i = 0; i < Math.min(7, daily.time.length); i++) {
        const date = new Date(daily.time[i]);
        const weatherInfo = WEATHER_CODES[daily.weather_code[i]] || WEATHER_CODES[0];
        
        const card = document.createElement('div');
        card.className = 'forecast-card fade-in';
        card.style.animationDelay = `${i * 0.1}s`;
        
        const isToday = i === 0;
        const dayName = isToday ? 'Today' : date.toLocaleDateString('en-US', { weekday: 'short' });
        
        card.innerHTML = `
            <div class="forecast-day">${dayName}</div>
            <div class="forecast-date">${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
            <div class="forecast-icon">${weatherInfo.icon}</div>
            <div class="forecast-temps">
                <span class="high-temp">${formatTemperature(daily.temperature_2m_max[i])}</span>
                <span class="low-temp">${formatTemperature(daily.temperature_2m_min[i])}</span>
            </div>
            <div class="forecast-condition">${weatherInfo.condition}</div>
        `;
        
        card.addEventListener('click', () => {
            showDetailedDayView(daily, i, weatherInfo, date);
        });
        
        container.appendChild(card);
    }
}

function showDetailedDayView(daily, dayIndex, weatherInfo, date) {
    // Create detailed view modal
    const modal = createDetailedModal();
    
    const isToday = dayIndex === 0;
    const dayName = isToday ? 'Today' : date.toLocaleDateString('en-US', { weekday: 'long' });
    
    const precipitation = daily.precipitation_sum[dayIndex] || 0;
    const windSpeed = daily.wind_speed_10m_max[dayIndex] || 0;
    const uvIndex = daily.uv_index_max[dayIndex] || 0;
    
    modal.querySelector('.modal-header h3').innerHTML = `
        ${weatherInfo.icon} ${dayName} Details
    `;
    
    // Get hourly data for this day
    const hourlyForDay = getHourlyDataForDay(currentWeatherData.hourly, date);
    
    modal.querySelector('.modal-body').innerHTML = `
        <div class="day-overview">
            <h4>${date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</h4>
            <p class="main-condition">${weatherInfo.description}</p>
            
            <div class="day-stats">
                <div class="stat-item">
                    <span class="stat-label">🌡️ High</span>
                    <span class="stat-value">${formatTemperature(daily.temperature_2m_max[dayIndex])}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">🌡️ Low</span>
                    <span class="stat-value">${formatTemperature(daily.temperature_2m_min[dayIndex])}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">🌧️ Precipitation</span>
                    <span class="stat-value">${precipitation.toFixed(1)} mm</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">💨 Max Wind</span>
                    <span class="stat-value">${windSpeed.toFixed(1)} km/h</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">☀️ UV Index</span>
                    <span class="stat-value">${uvIndex.toFixed(1)}</span>
                </div>
            </div>
        </div>
        
        <div class="hourly-details">
            <h4>Hourly Forecast</h4>
            <div class="hourly-detail-cards">
                ${hourlyForDay.map(hourData => `
                    <div class="hourly-detail-card">
                        <div class="hour">${formatHour(new Date(hourData.time))}</div>
                        <div class="hour-icon">${(WEATHER_CODES[hourData.weather_code] || WEATHER_CODES[0]).icon}</div>
                        <div class="hour-temp">${formatTemperature(hourData.temperature)}</div>
                        <div class="hour-humidity">${Math.round(hourData.humidity)}%</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.classList.remove('hidden');
}

function getHourlyDataForDay(hourlyData, targetDate) {
    const targetDateStr = targetDate.toISOString().split('T')[0];
    const hourlyForDay = [];
    
    for (let i = 0; i < hourlyData.time.length; i++) {
        const hourTime = new Date(hourlyData.time[i]);
        const hourDateStr = hourTime.toISOString().split('T')[0];
        
        if (hourDateStr === targetDateStr) {
            hourlyForDay.push({
                time: hourlyData.time[i],
                temperature: hourlyData.temperature_2m[i],
                weather_code: hourlyData.weather_code[i],
                humidity: hourlyData.relative_humidity_2m[i]
            });
        }
    }
    
    return hourlyForDay.slice(0, 8); // Show 8 hours max to fit in modal
}

function createDetailedModal() {
    const modal = document.createElement('div');
    modal.className = 'modal detailed-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3></h3>
                <button class="close-btn" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button class="btn btn--secondary" onclick="this.closest('.modal').remove()">Close</button>
            </div>
        </div>
    `;
    
    // Add styles for the detailed modal
    if (!document.getElementById('detailed-modal-styles')) {
        const styles = document.createElement('style');
        styles.id = 'detailed-modal-styles';
        styles.textContent = `
            .detailed-modal .modal-content { max-width: 600px; max-height: 80vh; overflow-y: auto; }
            .day-overview { margin-bottom: var(--space-24); }
            .main-condition { font-size: var(--font-size-lg); color: var(--color-text-secondary); margin-bottom: var(--space-16); }
            .day-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: var(--space-12); }
            .stat-item { text-align: center; padding: var(--space-12); background: var(--color-bg-1); border-radius: var(--radius-base); }
            .stat-label { display: block; font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-bottom: var(--space-4); }
            .stat-value { font-weight: var(--font-weight-semibold); }
            .hourly-details h4 { margin-bottom: var(--space-16); }
            .hourly-detail-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(80px, 1fr)); gap: var(--space-8); }
            .hourly-detail-card { text-align: center; padding: var(--space-8); background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-sm); }
            .hour { font-size: var(--font-size-sm); font-weight: var(--font-weight-medium); }
            .hour-icon { font-size: var(--font-size-lg); margin: var(--space-4) 0; }
            .hour-temp { font-weight: var(--font-weight-semibold); }
            .hour-humidity { font-size: var(--font-size-sm); color: var(--color-text-secondary); }
        `;
        document.head.appendChild(styles);
    }
    
    return modal;
}

// Temperature and formatting utilities
function formatTemperature(temp) {
    if (temp === null || temp === undefined) return '--°';
    
    const value = isCelsius ? temp : (temp * 9/5) + 32;
    const unit = isCelsius ? '°C' : '°F';
    return `${Math.round(value)}${unit}`;
}

function formatDateTime() {
    return new Date().toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatHour(date) {
    return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        hour12: true
    });
}

// UI state management
function showLoading() {
    document.getElementById('loadingOverlay').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hidden');
}

function showErrorModal(message) {
    document.getElementById('errorMessage').textContent = message;
    document.getElementById('errorModal').classList.remove('hidden');
}

function hideErrorModal() {
    document.getElementById('errorModal').classList.add('hidden');
}

function toggleTemperatureUnit() {
    isCelsius = !isCelsius;
    document.getElementById('tempToggle').textContent = isCelsius ? '°C' : '°F';
    
    // Update all temperature displays
    if (currentLocation && currentWeatherData) {
        updateWeatherDisplay(currentWeatherData, currentLocation.name);
    }
    
    savePreferences();
}

function handleRefresh() {
    const refreshIcon = document.querySelector('.refresh-icon');
    refreshIcon.classList.add('spinning');
    
    if (currentLocation) {
        fetchWeatherData(currentLocation.lat, currentLocation.lon, currentLocation.name)
            .finally(() => {
                setTimeout(() => {
                    refreshIcon.classList.remove('spinning');
                }, 1000);
            });
    } else {
        setTimeout(() => {
            refreshIcon.classList.remove('spinning');
        }, 1000);
    }
}

function handleRetry() {
    hideErrorModal();
    if (currentLocation) {
        fetchWeatherData(currentLocation.lat, currentLocation.lon, currentLocation.name);
    } else {
        tryGetCurrentLocation();
    }
}

function handleWindowFocus() {
    // Refresh data when window regains focus after 5 minutes
    if (lastUpdateTime && Date.now() - lastUpdateTime > 5 * 60 * 1000) {
        if (currentLocation) {
            fetchWeatherData(currentLocation.lat, currentLocation.lon, currentLocation.name);
        }
    }
}

function updateLastUpdated() {
    lastUpdateTime = Date.now();
    document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

function setupAutoRefresh() {
    // Auto-refresh every 30 minutes
    autoRefreshInterval = setInterval(() => {
        if (currentLocation) {
            fetchWeatherData(currentLocation.lat, currentLocation.lon, currentLocation.name);
        }
    }, 30 * 60 * 1000);
}

// Local storage functions
function savePreferences() {
    try {
        const prefs = {
            isCelsius: isCelsius,
            lastLocation: currentLocation,
            lastUpdate: Date.now()
        };
        // Note: localStorage is not available in sandbox, but we'll keep the structure
        // localStorage.setItem('weatherAppPrefs', JSON.stringify(prefs));
    } catch (error) {
        console.warn('Failed to save preferences:', error);
    }
}

function loadPreferences() {
    try {
        // Note: localStorage is not available in sandbox
        // const prefs = localStorage.getItem('weatherAppPrefs');
        // if (prefs) {
        //     const parsed = JSON.parse(prefs);
        //     if (typeof parsed.isCelsius === 'boolean') {
        //         isCelsius = parsed.isCelsius;
        //         document.getElementById('tempToggle').textContent = isCelsius ? '°C' : '°F';
        //     }
        //     return parsed;
        // }
    } catch (error) {
        console.warn('Failed to load preferences:', error);
    }
    
    return {};
}

// Error handling
window.addEventListener('error', (e) => {
    console.error('Unhandled error:', e.error);
    showErrorModal('Something went wrong. Please refresh the page and try again.');
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('Unhandled promise rejection:', e.reason);
    e.preventDefault();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
    }
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
});